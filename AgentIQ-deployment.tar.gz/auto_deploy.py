#!/usr/bin/env python3
"""
Fully automated AgentIQ deployment to Render
"""

import os
import json
import requests
import subprocess
import time
import webbrowser
from typing import Dict, Any, Optional

class AgentIQDeployer:
    def __init__(self):
        self.repo_name = "AgentIQ"
        self.repo_description = "Continuous agent evaluation platform with LLM-powered insights"
        
    def run_cmd(self, cmd: str) -> tuple[str, int]:
        """Execute shell command"""
        result = subprocess.run(cmd, shell=True, capture_output=True, text=True)
        return result.stdout.strip(), result.returncode
    
    def setup_git_config(self):
        """Configure Git if not already configured"""
        name, _ = self.run_cmd("git config user.name")
        email, _ = self.run_cmd("git config user.email")
        
        if not name:
            self.run_cmd('git config user.name "AgentIQ Platform"')
        if not email:
            self.run_cmd('git config user.email "platform@agentiq.dev"')
    
    def create_github_repo_via_web(self) -> str:
        """Open GitHub in browser for manual repo creation"""
        print("🌐 Opening GitHub to create repository...")
        
        # Construct GitHub new repo URL with pre-filled data
        github_url = (
            "https://github.com/new?"
            f"repository_name={self.repo_name}&"
            f"description={self.repo_description.replace(' ', '+')}&"
            "visibility=public"
        )
        
        try:
            webbrowser.open(github_url)
            print("✅ GitHub opened in browser")
        except Exception as e:
            print(f"❌ Could not open browser: {e}")
        
        print(f"""
📋 Repository Details:
   Name: {self.repo_name}
   Description: {self.repo_description}
   Visibility: Public
   Initialize: No (we have existing code)

🔗 Manual URL: {github_url}
        """)
        
        return input("✋ After creating the repo, paste the HTTPS clone URL here: ").strip()
    
    def prepare_deployment_files(self):
        """Ensure all deployment files are ready"""
        print("📦 Preparing deployment files...")
        
        # Update .gitignore to exclude sensitive files
        gitignore_content = """
# Python
__pycache__/
*.py[cod]
*$py.class
*.so
.Python
venv/
env/
ENV/

# Environment variables
.env
.env.local

# Database
*.db
*.sqlite3
agentiq.db

# IDE
.vscode/
.idea/
*.swp
*.swo

# OS
.DS_Store
Thumbs.db

# Logs
*.log

# Railway
.railway/

# Test artifacts
.coverage
.pytest_cache/
.tox/

# Deployment scripts (keep local)
deploy_to_render.py
auto_deploy.py
        """.strip()
        
        with open(".gitignore", "w") as f:
            f.write(gitignore_content)
        
        print("✅ Deployment files ready")
    
    def push_to_github(self, repo_url: str) -> bool:
        """Push code to GitHub"""
        print(f"📤 Pushing code to {repo_url}...")
        
        self.setup_git_config()
        
        # Add all files and commit
        self.run_cmd("git add .")
        output, code = self.run_cmd('git commit -m "Deploy AgentIQ platform to production\n\n🤖 Generated with [Claude Code](https://claude.ai/code)\n\nCo-Authored-By: Claude <noreply@anthropic.com>"')
        
        if code != 0 and "nothing to commit" not in output:
            print(f"⚠️  Commit issue: {output}")
        
        # Add remote and push
        self.run_cmd("git remote remove origin 2>/dev/null || true")  # Remove if exists
        self.run_cmd(f"git remote add origin {repo_url}")
        self.run_cmd("git branch -M main")
        
        print("🚀 Pushing to GitHub...")
        output, code = self.run_cmd("git push -u origin main")
        
        if code != 0:
            print(f"❌ Git push failed: {output}")
            if "authentication" in output.lower() or "permission" in output.lower():
                print("""
🔑 Authentication Required:
   1. Go to https://github.com/settings/tokens
   2. Generate a new token (classic)
   3. Select: repo, workflow
   4. Use: git remote set-url origin https://USERNAME:TOKEN@github.com/USERNAME/AgentIQ.git
                """)
            return False
        
        print("✅ Code pushed to GitHub successfully")
        return True
    
    def open_render_deployment(self, github_repo_url: str):
        """Open Render for deployment"""
        print("🚀 Opening Render for deployment...")
        
        # Extract repo path from URL
        repo_path = github_repo_url.replace("https://github.com/", "").replace(".git", "")
        
        # Render new service URL
        render_url = "https://dashboard.render.com/blueprints/new"
        
        try:
            webbrowser.open(render_url)
            print("✅ Render dashboard opened")
        except Exception as e:
            print(f"❌ Could not open browser: {e}")
        
        print(f"""
🎯 Render Deployment Instructions:

1. 🔗 Connect GitHub: Link your GitHub account if not already connected
2. 📁 Select Repository: {repo_path}
3. 📄 Blueprint Detected: Render will automatically detect render.yaml
4. 🔍 Review Services:
   ✅ PostgreSQL Database (agentiq-db) - Free tier
   ✅ Web Service (agentiq-api) - Free tier
5. 🔐 Environment Variables: Already configured in render.yaml
6. ⚡ Deploy: Click "Apply" to start deployment

📊 Expected Timeline:
   Database: ~2-3 minutes
   Web Service: ~5-7 minutes  
   Total: ~10 minutes

🔗 Manual Render URL: {render_url}
        """)
    
    def deploy(self):
        """Main deployment flow"""
        print("🤖 AgentIQ Fully Automated Render Deployment")
        print("=" * 55)
        
        # Check prerequisites
        if not os.path.exists("render.yaml"):
            print("❌ render.yaml not found. Please run from AgentIQ root directory.")
            return
        
        try:
            # Step 1: Prepare files
            self.prepare_deployment_files()
            
            # Step 2: Create GitHub repository  
            github_repo_url = self.create_github_repo_via_web()
            
            if not github_repo_url:
                print("❌ GitHub repository URL required")
                return
            
            # Step 3: Push code to GitHub
            if not self.push_to_github(github_repo_url):
                return
            
            # Step 4: Open Render for deployment
            self.open_render_deployment(github_repo_url)
            
            print("\n🎉 Deployment initiated successfully!")
            print("""
📝 Next Steps:
   1. Complete Render deployment in the opened browser
   2. Wait ~10 minutes for deployment to complete  
   3. Test the deployed API
   4. Load demo data to production
   5. Prepare launch post with production URLs
            """)
            
        except KeyboardInterrupt:
            print("\n⚠️  Deployment cancelled by user")
        except Exception as e:
            print(f"❌ Deployment error: {e}")

if __name__ == "__main__":
    deployer = AgentIQDeployer()
    deployer.deploy()