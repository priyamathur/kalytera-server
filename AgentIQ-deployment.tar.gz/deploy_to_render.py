#!/usr/bin/env python3
"""
Automated AgentIQ deployment to Render via GitHub
"""

import os
import json
import requests
import subprocess
import time
from typing import Dict, Any

def run_command(cmd: str) -> tuple[str, int]:
    """Run shell command and return output, exit code"""
    result = subprocess.run(cmd, shell=True, capture_output=True, text=True)
    return result.stdout.strip(), result.returncode

def create_github_repo(repo_name: str = "AgentIQ") -> str:
    """Create GitHub repository using API"""
    print(f"🔧 Creating GitHub repository: {repo_name}")
    
    # Check if git is configured
    name, _ = run_command("git config user.name")
    email, _ = run_command("git config user.email")
    
    if not name:
        run_command('git config user.name "AgentIQ Deployer"')
    if not email:
        run_command('git config user.email "deployer@agentiq.dev"')
    
    # For now, return instructions for manual creation
    return f"""
    🚧 GitHub Repository Creation Required:
    
    Please create a GitHub repository manually:
    1. Go to https://github.com/new
    2. Repository name: {repo_name}
    3. Description: "Continuous agent evaluation platform with LLM-powered insights"
    4. Public repository
    5. Initialize with README: No (we have existing code)
    6. Click "Create repository"
    
    Then run: python deploy_to_render.py --github-url YOUR_REPO_URL
    """

def push_to_github(repo_url: str) -> bool:
    """Push code to GitHub repository"""
    print(f"📤 Pushing code to {repo_url}")
    
    # Remove .git if exists and reinitialize
    run_command("rm -rf .git")
    run_command("git init")
    run_command("git add .")
    run_command('git commit -m "Initial AgentIQ platform deployment"')
    
    # Add remote and push
    run_command(f"git remote add origin {repo_url}")
    run_command("git branch -M main")
    
    output, code = run_command("git push -u origin main")
    if code != 0:
        print(f"❌ Git push failed: {output}")
        return False
    
    print("✅ Code pushed to GitHub successfully")
    return True

def deploy_to_render_blueprint(github_repo: str) -> Dict[str, Any]:
    """Deploy to Render using Blueprint API"""
    print("🚀 Deploying to Render using Blueprint...")
    
    # This would require Render API token
    # For now, return manual instructions
    return {
        "status": "manual_required",
        "instructions": f"""
        🚀 Render Deployment Steps:
        
        1. Go to https://render.com/
        2. Sign up/Login with GitHub account
        3. Click "New +" → "Blueprint"
        4. Connect repository: {github_repo}
        5. Render will detect render.yaml automatically
        6. Review services:
           ✅ PostgreSQL (agentiq-db)
           ✅ Web service (agentiq-api)
        7. Environment variables already configured
        8. Click "Apply" to deploy
        
        Expected deployment time: ~10 minutes
        """
    }

def main():
    """Main deployment orchestrator"""
    print("🤖 AgentIQ Automated Render Deployment")
    print("=" * 50)
    
    # Check if we're in the right directory
    if not os.path.exists("render.yaml"):
        print("❌ render.yaml not found. Please run from AgentIQ root directory.")
        return
    
    # Step 1: GitHub repository
    if len(os.sys.argv) > 1 and "--github-url" in os.sys.argv:
        github_url = os.sys.argv[os.sys.argv.index("--github-url") + 1]
        success = push_to_github(github_url)
        if not success:
            return
            
        # Step 2: Deploy to Render
        result = deploy_to_render_blueprint(github_url)
        print(result["instructions"])
        
    else:
        # Step 1: Create GitHub repo (manual for now)
        instructions = create_github_repo()
        print(instructions)

if __name__ == "__main__":
    main()